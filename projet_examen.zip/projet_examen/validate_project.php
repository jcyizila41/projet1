<?php
session_start(); // Démarrer la session pour vérifier si l'administrateur est connecté

// Inclure la connexion à la base de données
require('db_connect.php');

// Vérifier si l'utilisateur est connecté et est un administrateur
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    die("Accès refusé. Seuls les administrateurs peuvent valider les projets.");
}

// Vérifier si un projet doit être validé ou rejeté
if (isset($_GET['action']) && isset($_GET['id'])) {
    $project_id = (int)$_GET['id'];
    $action = $_GET['action'];

    // Mettre à jour le statut du projet en fonction de l'action
    if ($action === 'approve') {
        $sql = "UPDATE projects SET status = 'approved' WHERE id = ?";
    } elseif ($action === 'reject') {
        $sql = "UPDATE projects SET status = 'rejected' WHERE id = ?";
    } else {
        die("Action non valide.");
    }

    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $project_id);
    if (mysqli_stmt_execute($stmt)) {
        echo "Le projet a été " . ($action === 'approve' ? "approuvé" : "rejeté") . " avec succès.";
    } else {
        echo "Erreur lors de la mise à jour du projet : " . mysqli_error($conn);
    }
    mysqli_stmt_close($stmt);
}

// Récupérer tous les projets en attente de validation
$sql = "SELECT * FROM projects WHERE status = 'pending' ORDER BY created_at DESC";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Validation des Projets</title>
    <!-- Lien vers Bootstrap -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h1 class="text-center">Validation des Projets</h1>
    <div class="row">
        <?php if (mysqli_num_rows($result) > 0): ?>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($row['title']); ?></h5>
                            <p class="card-text"><?php echo htmlspecialchars(substr($row['description'], 0, 100)); ?>...</p>
                            <a href="<?php echo htmlspecialchars($row['file']); ?>" target="_blank" class="btn btn-secondary">Voir le fichier</a>
                            <a href="validate_project.php?action=approve&id=<?php echo $row['id']; ?>" class="btn btn-success mt-2">Approuver</a>
                            <a href="validate_project.php?action=reject&id=<?php echo $row['id']; ?>" class="btn btn-danger mt-2">Rejeter</a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p class="text-center">Aucun projet en attente de validation.</p>
        <?php endif; ?>
    </div>
</div>

<!-- Scripts Bootstrap -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
// Fermer la connexion à la base de données
mysqli_close($conn);
?>
