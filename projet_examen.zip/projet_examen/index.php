<?php
// Inclure la connexion à la base de données
require('db_connect.php');

// Démarrer la session
session_start();

// Vérifier si l'utilisateur est connecté et récupérer son ID
$user_id = null;
if (isset($_SESSION['id'])) {
    $user_id = $_SESSION['id'];
}

// Récupérer tous les projets approuvés
$sql = "SELECT * FROM projects WHERE status = 'approved' ORDER BY created_at DESC";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accueil - Projets de Fin d'Année</title>
    <!-- Lien vers Bootstrap -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .card-img-top {
            height: 200px;
            object-fit: cover;
        }
        .card-body {
            min-height: 150px;
        }
        .project-card {
            margin-bottom: 30px;
        }
        .container {
            margin-top: 20px;
        }
        .comments {
            margin-top: 10px;
            border-top: 1px solid #ddd;
            padding-top: 10px;
        }
        .comment {
            margin-bottom: 10px;
        }
        .comment-author {
            font-weight: bold;
        }
        .like-btn {
            cursor: pointer;
        }
    </style>
</head>
<body>

<div class="container mt-5">
    <h1 class="text-center mb-4">Projets de Fin d'Année</h1>

    <!-- Afficher l'ID de l'utilisateur connecté si la session est active -->
    <?php if ($user_id !== null): ?>
        <div class="alert alert-info text-center">
            Utilisateur connecté - ID : <?php echo htmlspecialchars($user_id); ?>
        </div>
    <?php endif; ?>

    <div class="text-center mb-4">
        <a href="submission.php" class="btn btn-primary">Soumettre un Projet</a>
        <a href="login.php" class="btn btn-secondary">Connexion</a>
    </div>

    <!-- Liste des Projets -->
    <div class="row">
        <?php while ($row = mysqli_fetch_assoc($result)) {
            $project_id = $row['id'];
            
            // Compter les "likes" pour le projet actuel
            $sql_likes_count = "SELECT COUNT(*) as like_count FROM project_likes WHERE project_id = $project_id";
            $result_likes_count = mysqli_query($conn, $sql_likes_count);
            $like_count = mysqli_fetch_assoc($result_likes_count)['like_count'];
            
            // Vérifier si l'utilisateur a déjà "aimé" ce projet
            $user_liked = false;
            if ($user_id !== null) {
                $sql_user_like = "SELECT COUNT(*) as user_like FROM project_likes WHERE project_id = $project_id AND user_id = $user_id";
                $result_user_like = mysqli_query($conn, $sql_user_like);
                $user_liked = mysqli_fetch_assoc($result_user_like)['user_like'] > 0;
            }
        ?>
            <div class="col-md-4 project-card">
                <div class="card">
                    <?php if (!empty($row['file'])): ?>
                        <img src="<?php echo htmlspecialchars($row['file']); ?>" class="card-img-top" alt="Image du projet">
                    <?php else: ?>
                        <img src="default-image.jpg" class="card-img-top" alt="Image du projet">
                    <?php endif; ?>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($row['title']); ?></h5>
                        <p class="card-text"><?php echo htmlspecialchars(substr($row['description'], 0, 100)); ?>...</p>
                        <a href="project_details.php?id=<?php echo $row['id']; ?>" class="btn btn-info">Voir Détails</a>

                        <!-- Affichage des commentaires pour chaque projet -->
                        <div class="comments">
                            <?php
                            $sql_comments = "SELECT * FROM comments WHERE project_id = $project_id ORDER BY created_at DESC LIMIT 3";
                            $comments = mysqli_query($conn, $sql_comments);

                            if (mysqli_num_rows($comments) > 0):
                                while ($comment = mysqli_fetch_assoc($comments)): ?>
                                    <div class="comment">
                                        <p class="comment-author"><?php echo htmlspecialchars($comment['username']); ?></p>
                                        <p><?php echo htmlspecialchars($comment['comment']); ?></p>
                                        <small class="text-muted"><?php echo htmlspecialchars($comment['created_at']); ?></small>
                                    </div>
                                <?php endwhile;
                            else: ?>
                                <p>Aucun commentaire pour le moment.</p>
                            <?php endif; ?>
                        </div>

                        <!-- Bouton "J'aime" -->
                        <?php if ($user_id !== null): ?>
                            <button class="btn btn-<?php echo $user_liked ? 'secondary' : 'primary'; ?> like-btn" data-project-id="<?php echo $project_id; ?>">
                                <?php echo $user_liked ? 'Je n\'aime plus' : 'J\'aime'; ?> <span class="like-count"><?php echo $like_count; ?></span>
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
</div>

<!-- Scripts Bootstrap et jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
$(document).ready(function() {
    $('.like-btn').click(function() {
        var button = $(this);
        var projectId = button.data('project-id');
        var isLiked = button.hasClass('btn-primary');

        $.ajax({
            url: 'like_project.php',
            type: 'POST',
            data: {
                project_id: projectId,
                like: isLiked ? 0 : 1 // 0 pour retirer le "like", 1 pour ajouter
            },
            success: function(response) {
                var data = JSON.parse(response);
                if (data.success) {
                    var newCount = data.like_count;
                    button.toggleClass('btn-primary btn-secondary');
                    button.html((isLiked ? 'Je n\'aime plus' : 'J\'aime') + ' <span class="like-count">' + newCount + '</span>');
                } else {
                    alert('Erreur lors du traitement de votre demande.');
                }
            }
        });
    });
});
</script>
</body>
</html>
