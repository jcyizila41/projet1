<?php
require('db_connect.php');
require 'vendor/autoload.php'; // Assurez-vous que le chemin est correct

use PhpOffice\PhpWord\IOFactory;

$project_id = isset($_GET['id']) ? (int)$_GET['id'] : 0; // Récupérer l'ID du projet à partir de l'URL

// Vérifier que l'ID du projet est valide
if ($project_id <= 0) {
    die("ID de projet invalide.");
}

// Afficher les détails du projet
$sql = "SELECT * FROM projects WHERE id = $project_id";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) == 0) {
    die("Projet non trouvé.");
}
$project = mysqli_fetch_assoc($result);

// Afficher les commentaires existants
$sql_comments = "SELECT * FROM comments WHERE project_id = $project_id ORDER BY created_at DESC";
$comments = mysqli_query($conn, $sql_comments);

// Ajouter un nouveau commentaire
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $comment = mysqli_real_escape_string($conn, $_POST['comment']);

    $sql_insert = "INSERT INTO comments (project_id, username, comment, created_at) VALUES ($project_id, '$username', '$comment', NOW())";
    if (mysqli_query($conn, $sql_insert)) {
        header("Location: project_details.php?id=$project_id"); // Rafraîchir la page
        exit;
    } else {
        echo "<div class='alert alert-danger'>Erreur lors de l'ajout du commentaire.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détails du Projet</title>
    <!-- Lien vers Bootstrap -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .project-details {
            margin-top: 20px;
        }
        .comment-form {
            margin-top: 30px;
        }
        .comment {
            margin-bottom: 15px;
        }
        .comment-author {
            font-weight: bold;
        }
        .file-viewer {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container project-details">
    <h1 class="text-center"><?php echo htmlspecialchars($project['title']); ?></h1>
    <p class="lead"><?php echo htmlspecialchars($project['description']); ?></p>

    <!-- Affichage du fichier associé -->
    <?php if (!empty($project['file'])): ?>
        <div class="file-viewer">
            <h4>Fichier associé :</h4>
            <?php 
            $file_path = htmlspecialchars($project['file']);
            $file_ext = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
            
            // Afficher le fichier en fonction de son type
            if (in_array($file_ext, ['jpg', 'jpeg', 'png', 'gif'])) {
                // Afficher les images
                echo "<img src='$file_path' class='img-fluid' alt='Fichier associé'>";
            } elseif (in_array($file_ext, ['pdf'])) {
                // Afficher les fichiers PDF
                echo "<iframe src='$file_path' width='100%' height='600px'></iframe>";
            } elseif (in_array($file_ext, ['txt'])) {
                // Afficher les fichiers texte
                echo "<pre>" . htmlspecialchars(file_get_contents($file_path)) . "</pre>";
            } elseif ($file_ext == 'docx') {
                // Afficher les fichiers DOCX
                $phpWord = IOFactory::load($file_path);
                $htmlWriter = IOFactory::createWriter($phpWord, 'HTML');
                ob_start();
                $htmlWriter->save('php://output');
                $docxContent = ob_get_clean();
                echo $docxContent;
            } else {
                // Pour les autres types de fichiers, fournir un lien de téléchargement
                $file_name = basename($file_path);
                echo "<a href='$file_path' class='btn btn-info' download>Télécharger $file_name</a>";
            }
            ?>
        </div>
    <?php endif; ?>

    <!-- Formulaire de commentaire -->
    <div class="comment-form">
        <h3>Ajouter un commentaire :</h3>
        <form method="post">
            <div class="form-group">
                <label for="username">Votre nom :</label>
                <input type="text" class="form-control" id="username" name="username" placeholder="Votre nom" required>
            </div>
            <div class="form-group">
                <label for="comment">Votre commentaire :</label>
                <textarea class="form-control" id="comment" name="comment" rows="4" placeholder="Votre commentaire" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Commenter</button>
        </form>
    </div>

    <!-- Affichage des commentaires -->
    <div class="mt-5">
        <h3>Commentaires :</h3>
        <?php while ($row = mysqli_fetch_assoc($comments)) { ?>
            <div class="comment">
                <p class="comment-author"><?php echo htmlspecialchars($row['username']); ?></p>
                <p><?php echo htmlspecialchars($row['comment']); ?></p>
                <small class="text-muted"><?php echo htmlspecialchars($row['created_at']); ?></small>
            </div>
        <?php } ?>
    </div>
</div>

<!-- Scripts Bootstrap -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
