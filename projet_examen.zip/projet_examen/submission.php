<?php
// Connexion à la base de données
require('db_connect.php');

// Démarrer la session
session_start();

// Vérifier si l'utilisateur est connecté et est un étudiant
if (isset($_SESSION['user_id'])) {
    $student_id = $_SESSION['user_id']; // Utiliser la valeur de la session si elle est définie
} else {
    // Gérer le cas où l'id n'est pas défini
    die("Erreur : ID étudiant non défini. Veuillez vous connecter d'abord.");
}

// Vérifier si le dossier 'uploads' existe et le créer s'il n'existe pas
$target_dir = "uploads/";
if (!is_dir($target_dir)) {
    mkdir($target_dir, 0777, true); // Crée le dossier avec les permissions d'écriture
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Récupérer et sécuriser les données du formulaire
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $promotion_id = intval($_POST['promotion_id']); // Assurez-vous que l'ID est un entier

    // Vérifier et sécuriser le fichier téléchargé
    if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
        $file = $_FILES['file']['name'];
        $file_tmp = $_FILES['file']['tmp_name'];
        $file_ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        $allowed_ext = array("jpg", "jpeg", "png", "pdf", "doc", "docx"); // Extensions de fichiers autorisées
        
        // Vérifier l'extension du fichier
        if (in_array($file_ext, $allowed_ext)) {
            // Définir un chemin de fichier unique pour éviter les collisions
            $file_path = $target_dir . uniqid() . "." . $file_ext;
            
            // Déplacer le fichier téléchargé vers le dossier 'uploads'
            if (move_uploaded_file($file_tmp, $file_path)) {
                // Insertion dans la base de données
                $sql = "INSERT INTO projects (title, description, file, student_id, promotion_id, status, created_at) VALUES ('$title', '$description', '$file_path', '$student_id', '$promotion_id', 'pending', NOW())";
                if (mysqli_query($conn, $sql)) {
                    echo "<div class='alert alert-success'>Projet soumis avec succès ! En attente de validation.</div>";
                } else {
                    echo "<div class='alert alert-danger'>Erreur lors de la soumission du projet : " . mysqli_error($conn) . "</div>";
                }
            } else {
                echo "<div class='alert alert-danger'>Erreur lors du téléchargement du fichier. Veuillez réessayer.</div>";
            }
        } else {
            echo "<div class='alert alert-warning'>Type de fichier non autorisé. Veuillez télécharger un fichier de type jpg, jpeg, png, pdf, doc, ou docx.</div>";
        }
    } else {
        echo "<div class='alert alert-warning'>Veuillez sélectionner un fichier à télécharger.</div>";
    }
}

// Récupérer les promotions disponibles
$sql_promotions = "SELECT * FROM promotions";
$result_promotions = mysqli_query($conn, $sql_promotions);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Soumettre un Projet</title>
    <!-- Lien vers Bootstrap -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h2 class="text-center">Soumettre un Projet</h2>
    <form method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="title">Titre du projet :</label>
            <input type="text" class="form-control" id="title" name="title" required>
        </div>
        <div class="form-group">
            <label for="description">Description du projet :</label>
            <textarea class="form-control" id="description" name="description" required></textarea>
        </div>
        <div class="form-group">
            <label for="file">Fichier :</label>
            <input type="file" class="form-control" id="file" name="file" required>
        </div>
        <div class="form-group">
            <label for="promotion">Promotion :</label>
            <select class="form-control" id="promotion" name="promotion_id" required>
                <option value="">Sélectionner une promotion</option>
                <?php while ($row_promotion = mysqli_fetch_assoc($result_promotions)): ?>
                    <option value="<?php echo $row_promotion['id']; ?>"><?php echo htmlspecialchars($row_promotion['name']); ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <input type="submit" class="btn btn-primary" value="Soumettre le projet">
    </form>
</div>

<!-- Scripts Bootstrap -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
