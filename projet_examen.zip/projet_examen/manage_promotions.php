<?php
// Connexion à la base de données
require('db_connect.php');

// Démarrer la session
session_start();

// Vérifier si l'utilisateur est connecté et est un administrateur
if ($_SESSION['role'] != 'admin') {
    header('Location: login.php');
    exit();
}

// Initialiser les variables d'erreur et de succès
$message = '';

// Ajouter une nouvelle promotion
if (isset($_POST['add_promotion'])) {
    $promotion_name = mysqli_real_escape_string($conn, $_POST['promotion_name']);
    if (!empty($promotion_name)) {
        $sql = "INSERT INTO promotions (name) VALUES ('$promotion_name')";
        if (mysqli_query($conn, $sql)) {
            $message = "<div class='alert alert-success'>Promotion ajoutée avec succès.</div>";
        } else {
            $message = "<div class='alert alert-danger'>Erreur lors de l'ajout de la promotion : " . mysqli_error($conn) . "</div>";
        }
    } else {
        $message = "<div class='alert alert-warning'>Veuillez entrer un nom de promotion.</div>";
    }
}

// Supprimer une promotion
if (isset($_GET['delete'])) {
    $promotion_id = intval($_GET['delete']);
    $sql = "DELETE FROM promotions WHERE id = $promotion_id";
    if (mysqli_query($conn, $sql)) {
        $message = "<div class='alert alert-success'>Promotion supprimée avec succès.</div>";
    } else {
        $message = "<div class='alert alert-danger'>Erreur lors de la suppression de la promotion : " . mysqli_error($conn) . "</div>";
    }
}

// Récupérer les promotions existantes
$sql = "SELECT * FROM promotions";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Promotions</title>
    <!-- Lien vers Bootstrap -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h2 class="text-center">Gestion des Promotions</h2>
    
    <?php echo $message; // Afficher les messages d'erreur ou de succès ?>

    <!-- Formulaire pour ajouter une nouvelle promotion -->
    <form method="post" class="mb-4">
        <div class="form-group">
            <label for="promotion_name">Nom de la promotion :</label>
            <input type="text" class="form-control" id="promotion_name" name="promotion_name" required>
        </div>
        <button type="submit" class="btn btn-primary" name="add_promotion">Ajouter Promotion</button>
    </form>

    <!-- Liste des promotions existantes -->
    <h3>Promotions Actuelles</h3>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nom</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo htmlspecialchars($row['name']); ?></td>
                <td>
                    <!-- Lien pour supprimer la promotion -->
                    <a href="manage_promotion.php?delete=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette promotion ?');">Supprimer</a>
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<!-- Scripts Bootstrap -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
