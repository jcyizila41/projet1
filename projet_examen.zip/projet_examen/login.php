<?php
session_start(); // Démarrer la session pour stocker les informations de l'utilisateur connecté

// Inclure la connexion à la base de données
require('db_connect.php');

// Initialiser les variables d'erreur
$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer les données du formulaire et les sécuriser
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    
    // Préparer la requête SQL pour vérifier l'utilisateur
    $sql = "SELECT * FROM users WHERE username = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result && mysqli_num_rows($result) > 0) { // Vérifier que l'utilisateur existe
        $user = mysqli_fetch_assoc($result);
        
        // Vérifier le mot de passe
        if (password_verify($password, $user['password'])) {
            // Stocker les informations de l'utilisateur dans la session
            $_SESSION['id'] = $user['id'];  // Utiliser 'id' pour rester cohérent avec les autres pages
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            
            // Rediriger l'utilisateur selon son rôle
            if ($user['role'] == 'admin') {
                header('Location: admin_dashboard.php'); // Redirection vers le tableau de bord de l'administrateur
            } else {
                header('Location: index.php'); // Redirection vers la page d'accueil pour les étudiants
            }
            exit;
        } else {
            $error = "Mot de passe incorrect.";
        }
    } else {
        $error = "Utilisateur non trouvé.";
    }

    mysqli_stmt_close($stmt); // Fermer la requête préparée
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
    <!-- Lien vers Bootstrap -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h2 class="text-center">Connexion</h2>
    <div class="row justify-content-center">
        <div class="col-md-6">
            <form method="POST" action="login.php">
                <div class="form-group">
                    <label for="username">Nom d'utilisateur :</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Mot de passe :</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>
                <button type="submit" class="btn btn-primary">Se connecter</button>
            </form>
        </div>
    </div>
</div>

<!-- Scripts Bootstrap -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
