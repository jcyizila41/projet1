<?php
require('db_connect.php');
session_start();

if (!isset($_SESSION['id']) || !isset($_POST['project_id']) || !isset($_POST['like'])) {
    echo json_encode(['success' => false]);
    exit;
}

$user_id = $_SESSION['id'];
$project_id = (int)$_POST['project_id'];
$like = (int)$_POST['like']; // 1 pour aimer, 0 pour ne pas aimer

if ($like) {
    // Ajouter un "like"
    $sql = "INSERT INTO project_likes (project_id, user_id) VALUES ($project_id, $user_id) ON DUPLICATE KEY UPDATE id=id";
} else {
    // Retirer un "like"
    $sql = "DELETE FROM project_likes WHERE project_id = $project_id AND user_id = $user_id";
}

if (mysqli_query($conn, $sql)) {
    // Récupérer le nouveau nombre de "likes"
    $sql_likes_count = "SELECT COUNT(*) as like_count FROM project_likes WHERE project_id = $project_id";
    $result_likes_count = mysqli_query($conn, $sql_likes_count);
    $like_count = mysqli_fetch_assoc($result_likes_count)['like_count'];

    echo json_encode(['success' => true, 'like_count' => $like_count]);
} else {
    echo json_encode(['success' => false]);
}
?>
