<?php
// Informations de connexion à la base de données
$servername = "localhost";  // L'hôte de la base de données (en général "localhost" pour XAMPP)
$username = "root";         // Le nom d'utilisateur MySQL (par défaut "root" pour XAMPP)
$password = "";             // Le mot de passe MySQL (par défaut vide pour XAMPP)
$dbname = "projets_faculte"; // Le nom de votre base de données

// Créer une connexion
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}

// Afficher un message si la connexion est réussie (facultatif)
// echo "Connexion réussie !";

?>
