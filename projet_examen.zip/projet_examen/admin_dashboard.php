<?php
// Connexion à la base de données
require('db_connect.php');

// Vérifier si l'utilisateur est connecté et est un administrateur
session_start();
if ($_SESSION['role'] != 'admin') {
    header('Location: login.php');
    exit();
}

// Récupérer les projets en attente
$sql = "SELECT * FROM projects WHERE status = 'pending'";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de Bord Administrateur</title>
    <!-- Lien vers Bootstrap -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h1 class="text-center mb-4">Projets en Attente de Validation</h1>
    <div class="text-center mb-4">
        <!-- Autres liens -->
        <a href="manage_promotions.php" class="btn btn-primary">Gérer les Promotions</a>
    </div>
    <?php if (mysqli_num_rows($result) > 0): ?>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Titre</th>
                    <th>Description</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['title']); ?></td>
                        <td><?php echo htmlspecialchars(substr($row['description'], 0, 100)); ?>...</td>
                        <td>
                            <form method="post" action="validate_project.php" style="display:inline;">
                                <input type="hidden" name="project_id" value="<?php echo $row['id']; ?>">
                                <button type="submit" name="approve" class="btn btn-success btn-sm">Approuver</button>
                            </form>
                            <form method="post" action="validate_project.php" style="display:inline;">
                                <input type="hidden" name="project_id" value="<?php echo $row['id']; ?>">
                                <button type="submit" name="reject" class="btn btn-danger btn-sm">Rejeter</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="text-center">Aucun projet en attente de validation.</p>
    <?php endif; ?>
</div>

<!-- Scripts Bootstrap -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
// Fermer la connexion à la base de données
mysqli_close($conn);
?>
